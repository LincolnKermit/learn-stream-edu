# learn-stream-edu
Collaborative platform to make education greater

![Learn Stream Edu](https://github.com/LincolnKermit/learn-stream-edu/blob/main/sources/banner-learn-stream-edu.png)



# Beta Version - Changes Logs
Since 15/09/24

- 18/09/24 : Changed and improved user's group



- 17/09/24 : Added login database to secure the courses from attackers or unauthorized people...



- 16/09/24 : Added pdf to html function in order to import courses 



- 15/09/24 : Optimized UI/UX and minors fixs... - Created and optimized UC control for server stats
![Mobile Render](https://github.com/LincolnKermit/learn-stream-edu/blob/main/sources/test-prod/test-prod-render.png)



