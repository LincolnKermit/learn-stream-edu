import os, time
from flask import Blueprint, flash, redirect, render_template, session, url_for
from pyfile.mylib.backuper import create_backup_zip
from pyfile.db import db
from pyfile.config.model import Classe, Homework, Matiere, User
from datetime import datetime
from flask import request
from flask import session, redirect, url_for, flash
from decoration import admin_required

learning = Blueprint('learning', __name__, template_folder='templates/admin')

@learning.route('/admin/add_matiere', methods=['GET', 'POST'])
def add_matiere():
    """ Ajouter une nouvelle lessons """
    if request.method == 'POST':
        # Récupérer les données du formulaire
        date_str = request.form.get('date')
        nomMatiere = request.form.get('nomMatiere')
        mainChemin = request.form.get('mainChemin')
        idf = request.form.get('idf')
        id_classe = request.form.get('idClasse')
        # Validation de la date
        try:
            parsed_date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            flash('Date invalide. Veuillez entrer une date au format AAAA-MM-JJ.', 'error')
            return render_template('/learning/add_matiere.html')

        # Vérifier que tous les champs requis sont remplis
        if not nomMatiere or not mainChemin:
            flash('Tous les champs sont obligatoires.', 'error')
            return render_template('/learning/add_matiere.html')

        # Créer une nouvelle instance de Matiere
        new_matiere = Matiere(
            date=parsed_date,
            id_classe=id_classe,
            nomMatiere=nomMatiere,
            mainChemin=mainChemin,
            idf=idf
        )

        # Ajouter à la base de données
        try:
            # Créer le répertoire pour la matière si nécessaire
            os.makedirs(f"./templates/learning/{nomMatiere}/", exist_ok=True)
            db.session.add(new_matiere)
            db.session.commit()
            flash('La matière a été ajoutée avec succès.', 'success')
            return redirect(url_for('admin.all_lessons'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erreur lors de l\'ajout de la matière : {str(e)}', 'error')

    return render_template('/learning/add_matiere.html', message=flash)


@learning.route('/add_lessons', methods=['GET', 'POST'])
def add_lessons():
    if request.method == 'POST':
        date = request.form['date']
        idClasse = request.form.get('idClasse')
        nomMatiere = request.form['nomMatiere']
        mainChemin = request.form['mainChemin']
        idf = request.form['idf']

        # Vérifie si la matière existe déjà
        matiere = Matiere.query.filter_by(nom=nomMatiere).first()
        
        if matiere is None and request.form.get('create'):
            # Crée une nouvelle matière si elle n'existe pas
            new_matiere = Matiere(nom=request.form['newMatiere'])
            db.session.add(new_matiere)
            db.session.commit()
            matiere = new_matiere
        
        # Ici, ajoute la leçon à la base de données (ajoute une logique pour l'enregistrement de la leçon)
        if matiere:
            # Logique pour ajouter la leçon
            # Exemple : 
            flash('Leçon ajoutée avec succès.', 'success')
        else:
            flash('Erreur lors de l\'ajout de la leçon.', 'danger')

    # Récupérer toutes les matières pour la boîte de sélection
    matieres = Matiere.query.all()
    return render_template('/learning/add_lessons.html', matieres=matieres)


"""
@laerning.route('/admin/delete_matiere/<int:id>', methods=['POST'])
def delete_matiere(id):
    Supprimer une matière
    matiere_to_delete = Matiere.query.get_or_404(id)  # Adjusted from 'Cour' to 'Matiere'
    try:
        try:
            os.remove(matiere_to_delete.mainChemin)
            create_backup_zip(matiere_to_delete.mainChemin, '/backup/lessons/')
        except Exception as e:
            print(e + " pas de fichier de cour à supprimer")
        
        # Supprimer la matière de la base de données
        db.session.delete(matiere_to_delete)
        db.session.commit()
        return redirect(url_for('admin.all_lessons'))
    except Exception as e:
        db.session.rollback()
        flash(f'Erreur lors de la suppression de la matière: {str(e)}', 'error')
        return redirect(url_for('admin.all_lessons'))
"""